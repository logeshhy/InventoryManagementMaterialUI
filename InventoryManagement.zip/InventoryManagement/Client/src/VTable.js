import React, { Component } from 'react';
class VTable extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (<div>df</div> );
    }
}
 
export default VTable;