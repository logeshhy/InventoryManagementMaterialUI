import React from "react";
export default function Content() {
  return <h1>I am Test Page</h1>;
}
