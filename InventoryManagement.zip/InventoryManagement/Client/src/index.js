import React from "react";
import ReactDOM from "react-dom";
import MainLayout from "./Layouts/HomePage"

ReactDOM.render(<MainLayout />, document.querySelector("#root"));
