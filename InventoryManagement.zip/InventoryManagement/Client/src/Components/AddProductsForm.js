import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import { FormGroup, FormControl } from "@material-ui/core";
import FloatingActionButtons from "./FormButton";
import Fab from "@material-ui/core/Fab";
import AddIcon from "@material-ui/icons/Add";
import EditIcon from "@material-ui/icons/Edit";
import AlertDialog from "./ConfirmationDialog";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";

const useStyles = makeStyles(theme => ({
  root: {
    "& > *": {
      margin: theme.spacing(2)
    }
  },
  formGroup: {
    "& > *": {
      margin: theme.spacing(1)
      //   width: 200
    }
  }
}));

export default function AddProducts() {
  // const [poName, pnName] = React.useState("");
  const initialState = {
    productName: "",
    productId: "",
    productBrand: "",
    productQuantity: "",
    productPrice: "",
    productType: ""
  };
  const [poName, pnName] = React.useState(initialState);
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    pnName({ ...initialState });
  };

  const handleReset = e => {
    e.preventDefault();
    pnName({ ...initialState });
  };

  // console.log(pnName)
  const handleName = e => {
    e.preventDefault();

    pnName({ ...poName, [e.target.name]: e.target.value });
  };

  // const handleProduct = (e) =>{
  //   e.preventDefault()
  //     pnName({... poName, productId: e.target.value})
  // };

  const handleSubmit = e => {
    e.preventDefault();
    // alert(`${poName.productName} ${poName.productId}`);
    console.log(JSON.stringify(poName));
    fetch("http://127.0.0.1:4000/add", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(poName)
    })
      .then(response => {
        console.log(response);
      })
      .catch(error => {
        console.log(error);
      });
    handleClose();
  };

  const classes = useStyles();
  return (
    <form className={classes.root} noValidate autoComplete="off" align="center">
      <div className={classes.formGroup}>
        <FormControl>
          <TextField
            label="Product Name"
            variant="outlined"
            size="small"
            value={poName.productName}
            name="productName"
            onChange={handleName}
          />
        </FormControl>
        <TextField
          label="Product ID"
          variant="outlined"
          size="small"
          value={poName.productId}
          name="productId"
          onChange={handleName}
        />
        <TextField
          label="Product Brand"
          variant="outlined"
          size="small"
          value={poName.productBrand}
          name="productBrand"
          onChange={handleName}
        />
      </div>
      <div className={classes.formGroup}>
        <TextField
          label="Product Quantity"
          variant="outlined"
          size="small"
          value={poName.productQuantity}
          name="productQuantity"
          onChange={handleName}
        />
        <TextField
          label="Buying Price"
          variant="outlined"
          size="small"
          value={poName.productPrice}
          name="productPrice"
          onChange={handleName}
        />
        <TextField
          label="Type"
          variant="outlined"
          size="small"
          value={poName.productType}
          name="productType"
          onChange={handleName}
        />
      </div>

      <Fab color="secondary" aria-label="edit" onClick={handleReset}>
        <EditIcon />
      </Fab>
      <Fab color="primary" aria-label="add" onClick={handleClickOpen}>
        <AddIcon />
      </Fab>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Update Stocks ?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you Sure ? you want to update Database !
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Disagree
          </Button>
          <Button onClick={handleSubmit} color="primary" autoFocus>
            Agree
          </Button>
        </DialogActions>
      </Dialog>
    </form>
  );
}
