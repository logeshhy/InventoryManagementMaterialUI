import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { FormGroup, FormControl } from "@material-ui/core";
import AddIcon from "@material-ui/icons/Add";
import EditIcon from "@material-ui/icons/Edit";
import Fab from "@material-ui/core/Fab";
import AlertDialog from "./ConfirmationDialog";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { Input } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const useStyles = makeStyles(theme => ({
  root: {
    "& > *": {
      margin: theme.spacing(2)
    }
  },
  formGroup: {
    "& > *": {
      margin: theme.spacing(1)
      //   width: 200
    }
  },
  table: {
    minWidth: 650,
    height: "300px"
  }
}));

export default function DeleteProductsForm() {
  const initialState = {
    idaddproducts: "",
    productName: "",
    productId: "",
    productBrand: "",
    productQuantity: "",
    productPrice: "",
    productType: ""
  };
  const [poName, pnName] = React.useState(initialState);

  const handleName = e => {
    const idAddProducts = e.target.value;
    e.preventDefault();
    pnName({ ...poName, idaddproducts: idAddProducts });
    handleTable(idAddProducts);
    console.log(poName);
  };

  async function handleTable(idAddProducts) {
    const id = poName.idaddproducts;
    const res = await fetch(
      "http://localhost:4000/productslist/" + idAddProducts
    );
    const data = await res.json();
    pnName(data.data);
    console.log(data.data);
  }

  useEffect(() => {
    handleTable();
  }, []);

  const classes = useStyles();
  return (
    <form className={classes.root} noValidate autoComplete="off" align="center">
      <div className={classes.formGroup}>
        <FormControl>
          <Input
            type="search"
            label="Product ID"
            variant="outlined"
            size="small"
            placeholder="Enter Product ID"
            value={poName.idaddproducts}
            name="idaddproducts"
            onChange={handleName}
          />

          <TableContainer className={classes.table} component={Paper}>
            <Table size="small" aria-label="a dense table" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>Product Code</TableCell>
                  <TableCell>Product Name</TableCell>
                  <TableCell align="right">Product ID</TableCell>
                  <TableCell align="right">Product Brand</TableCell>
                  <TableCell align="right">Product Quantity</TableCell>
                  <TableCell align="right">Product Price</TableCell>
                  <TableCell align="right">Product Type</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {poName.length &&
                  poName.map(row => (
                    <TableRow key={row.idaddproducts}>
                      <TableCell component="th" scope="row">
                        {row.idaddproducts}
                      </TableCell>
                      <TableCell component="th" scope="row">
                        {row.productName}
                      </TableCell>
                      <TableCell align="right">{row.productId}</TableCell>
                      <TableCell align="right">{row.productBrand}</TableCell>
                      <TableCell align="right">{row.productQuantity}</TableCell>
                      <TableCell align="right">{row.productPrice}</TableCell>
                      <TableCell align="right">{row.productType}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
          <div style={{ paddingBlockEnd: "0px" }}>
            <Fab color="secondary" aria-label="edit">
              <EditIcon />
            </Fab>
          </div>
        </FormControl>
      </div>
    </form>
  );
}
