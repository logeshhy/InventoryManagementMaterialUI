import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { FormGroup, FormControl } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { Input } from "@material-ui/core";
import MuiAlert from "@material-ui/lab/Alert";

const useStyles = makeStyles(theme => ({
  root: {
    "& > *": {
      margin: theme.spacing(2)
    }
  },
  formGroup: {
    "& > *": {
      margin: theme.spacing(1)
      //   width: 200
    }
  },
  table: {
    minWidth: 650,
    height: "300px"
  }
}));

export default function DeleteProductsForm() {
  const initialState = {
    idaddproducts: "",
    productName: "",
    productId: "",
    productBrand: "",
    productQuantity: "",
    productPrice: "",
    productType: ""
  };
  const [values, setValues] = React.useState(initialState);
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setValues({ ...initialState });
  };

  const handleReset = e => {
    e.preventDefault();
    setValues({ ...initialState });
  };

  const handleName = e => {
    const idAddProducts = e.target.value;
    console.log(idAddProducts);
    e.preventDefault();
    setValues({ ...values, [e.target.name]: idAddProducts });
    console.log(values);
  };

  const handleN = e => {
    const idAddProducts = values.idaddproducts;
    console.log(idAddProducts);
    e.preventDefault();
    setValues({ ...values, [e.target.name]: idAddProducts });
    handleList(idAddProducts);
    console.log(values);
  };

  async function handleList(idAddProducts) {
    const res = await fetch(
      "http://localhost:4000/productslist/delete/" + idAddProducts
    );
    const data = await res.json();
    setValues(data.data);
    console.log(data.data);
    handleClose();
  }

  useEffect(() => {
    handleList();
  }, []);

  const classes = useStyles();
  return (
    <form className={classes.root} noValidate autoComplete="off" align="center">
      <div className={classes.formGroup}>
        <FormControl>
          <Input
            type="search"
            label="Product ID"
            variant="outlined"
            size="small"
            placeholder="Enter Product Code"
            value={values.idaddproducts}
            name="idaddproducts"
            onChange={e => handleName(e)}
          />
        </FormControl>

        <Button variant="outlined" onClick={handleClickOpen}>
          Delete
        </Button>

        <Dialog
          open={open}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Update Stocks ?"}</DialogTitle>
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              Are you Sure ? you want to Delete Product from Database !
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              Disagree
            </Button>
            <Button
              onClick={e => handleN(e) && handleClickOpen}
              color="primary"
              autoFocus
            >
              Agree
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    </form>
  );
}
