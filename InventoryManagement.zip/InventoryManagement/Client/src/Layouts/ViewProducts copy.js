import React, { Component } from 'react';

class ViewProducts extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      values : [],
     }
  }

componentDidMount(){
  fetch("http://localhost:4000/productslist")
  .then(res => res.json())
  .then(res => this.setState({values: res.data})) //this data variable should be declared in server file
  .catch(error =>{
    if (error) 
    console.log(error)
  })
}

  render() { 
    const val = this.state.values
    console.log(val)
    return (  <div>
      {val.map(v => {
  return  <h4 key={v.idaddproducts}>{v.productName}{v.productId}{v.productBrand}</h4>})}
    </div>);
  }
}
 
export default ViewProducts;


