import React from "react";
import { Typography } from "@material-ui/core";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import purple from "@material-ui/core/colors/purple";
import blacklogo from "../img/blacklogo.png";
import logo from "../img/logo.png";

const theme = createMuiTheme({
  palette: {
    primary: { main: "#e91e63", contrastText: "#fff" },
    secondary: { main: "#fff", contrastText: "#fff" }
  },
  AddProductsBg: {
    flexGrow: 1,
    backgroundImage: `url(${logo})`,
    height: "100vh"
  }
});

function WelcomePage() {
  return (
    <MuiThemeProvider theme={theme}>
      <Typography variant="h4" align="center" color="secondary">
        {/* THE FUTURE IS HERE ! WE'RE REACT and NODE JS BROTHERS */}
        Inventory Management System
      </Typography>
      <div style={{ marginLeft: "595px", flexDirection: "row" }}>
        <Typography variant="subtitle" color="secondary">
          Developed by BOT Engineers
        </Typography>
        <div AddProductsBg></div>
      </div>
    </MuiThemeProvider>
  );
}
export default WelcomePage;
