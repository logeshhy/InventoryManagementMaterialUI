import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const useStyles = makeStyles({
  table: {
    minWidth: 650,
    height: "500px"
  }
});

export default function SimpleTable() {
  const classes = useStyles();
  const [values, setValues] = useState([]);

  async function handleTable() {
    const res = await fetch("http://localhost:4000/productslist");
    const data = await res.json();
    setValues(data.data);
    console.log(data.data);
  }

  useEffect(() => {
    handleTable();
  }, []);

  return (
    <TableContainer className={classes.table} component={Paper}>
      <Table size="small" aria-label="a dense table" stickyHeader>
        <TableHead>
          <TableRow>
            <TableCell>Product Code</TableCell>
            <TableCell>Product Name</TableCell>
            <TableCell align="right">Product ID</TableCell>
            <TableCell align="right">Product Brand</TableCell>
            <TableCell align="right">Product Quantity</TableCell>
            <TableCell align="right">Product Price</TableCell>
            <TableCell align="right">Product Type</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {values.length &&
            values.map(row => (
              <TableRow key={row.idaddproducts}>
                <TableCell component="th" scope="row">
                  {row.idaddproducts}
                </TableCell>
                <TableCell component="th" scope="row">
                  {row.productName}
                </TableCell>
                <TableCell align="right">{row.productId}</TableCell>
                <TableCell align="right">{row.productBrand}</TableCell>
                <TableCell align="right">{row.productQuantity}</TableCell>
                <TableCell align="right">{row.productPrice}</TableCell>
                <TableCell align="right">{row.productType}</TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    </TableContainer>

    //   <div>

    //       {console.log(values)}
    //       {values.length && values.map(v => {
    //     return  <h4 key={v.idaddproducts}>{v.productName}{v.productId}{v.productBrand}</h4>})}
    //     </div>
  );
}
