import React from "react";
import PropTypes from "prop-types";
import AppBar from "@material-ui/core/AppBar";
import CssBaseline from "@material-ui/core/CssBaseline";
import Divider from "@material-ui/core/Divider";
import Drawer from "@material-ui/core/Drawer";
import Hidden from "@material-ui/core/Hidden";
import IconButton from "@material-ui/core/IconButton";
import InboxIcon from "@material-ui/icons/MoveToInbox";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import MailIcon from "@material-ui/icons/Mail";
import MenuIcon from "@material-ui/icons/Menu";
import HomeIcon from "@material-ui/icons/Home";
import VisibilityIcon from "@material-ui/icons/Visibility";
import AddShoppingCartIcon from "@material-ui/icons/AddShoppingCart";
import RemoveShoppingCartIcon from "@material-ui/icons/RemoveShoppingCart";
import SearchIcon from "@material-ui/icons/Search";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import { makeStyles, useTheme } from "@material-ui/core/styles";
import { Switch, Route, Link, BrowserRouter } from "react-router-dom";
import TestPage from "../TestPage";
import AddProducts from "./AddProducts";
import BlueBackground from "../img/BlueBackground.png";
import ViewProducts from "./ViewProducts";
import SimpleTable from "./SimpleTable";
import MaterialTableDemo from "../VTable";
import WelcomePage from "./WelcomePage";
import SearchProduct from "./SearchProduct";
import DeleteProducts from "./DeleteProducts";
import blacklogo1 from "../img/blacklogo1.png";
import logo from "../img/logo.png";
import { ListItemSecondaryAction } from "@material-ui/core";

const drawerWidth = 240;

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex"
  },
  drawer: {
    [theme.breakpoints.up("sm")]: {
      width: drawerWidth,
      flexShrink: 0
    }
  },
  appBar: {
    marginLeft: drawerWidth,
    backgroundImage: `url(${BlueBackground})`,
    [theme.breakpoints.up("sm")]: {
      width: `calc(100% - ${drawerWidth}px)`
    }
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up("sm")]: {
      display: "none"
    }
  },
  toolbar: theme.mixins.toolbar,
  drawerPaper: {
    width: drawerWidth
    // backgroundImage: `url(${BlueBackground})`,
    // color: "White"
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    backgroundImage: `url(${BlueBackground})`,
    backgroundSize: "cover",
    height: "100vh"
  },
  table1: {
    width: "auto",
    height: "200px"
  },

  wrapperBg: {
    backgroundImage: `url(${logo})`
    // height: "100vh"
  }
}));

function MainLayout(props) {
  const { container } = props;
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <div>
      <div className={classes.toolbar}>
        <div style={{ textAlign: "center", paddingTop: "20px" }}>
          <h1>DASHBOARD</h1>

          {/* <div className={classes.wrapperBg}></div> */}
        </div>
      </div>
      <Divider />
      {/* <List>
        {["Inbox", "Starred"].map((text, index) => (
          <ListItem key={text} component={Link} to={"/" + text}>
            <ListItemIcon>
              {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
            </ListItemIcon>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      
      </List> */}

      <List>
        <ListItem button component={Link} to={"/WelcomePage"}>
          <ListItemIcon>
            <HomeIcon />
          </ListItemIcon>
          <ListItemText primary="Home" />
        </ListItem>
      </List>
      <Divider />
      <List>
        <ListItem button component={Link} to={"/SimpleTable"}>
          <ListItemIcon>
            <VisibilityIcon />
          </ListItemIcon>
          <ListItemText primary="View Products" />
        </ListItem>
      </List>
      <Divider />
      <List>
        <ListItem button component={Link} to={"/AddProducts"}>
          <ListItemIcon>
            <AddShoppingCartIcon />
          </ListItemIcon>
          <ListItemText primary="Add Products" />
        </ListItem>
        <ListItem button component={Link} to={"/SearchProduct"}>
          <ListItemIcon>
            <SearchIcon />
          </ListItemIcon>
          <ListItemText primary="Search Products" />
        </ListItem>
        <Divider />
        <ListItem button component={Link} to={"/DeleteProducts"}>
          <ListItemIcon>
            <RemoveShoppingCartIcon />
          </ListItemIcon>
          <ListItemText primary="Delete Product" />
        </ListItem>
        <Divider />
        <ListItem button component={Link} to={"/ViewProducts"}>
          <ListItemIcon>
            <MailIcon />
          </ListItemIcon>
          <ListItemText primary="Database Datas" />
        </ListItem>
      </List>
    </div>
  );

  return (
    <div className={classes.root}>
      <CssBaseline />

      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap>
            Inventory Management
          </Typography>
        </Toolbar>
      </AppBar>
      <BrowserRouter>
        <nav className={classes.drawer} aria-label="mailbox folders">
          {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
          <Hidden smUp implementation="css">
            <Drawer
              container={container}
              variant="temporary"
              anchor={theme.direction === "rtl" ? "right" : "left"}
              open={mobileOpen}
              onClose={handleDrawerToggle}
              classes={{
                paper: classes.drawerPaper
              }}
              ModalProps={{
                keepMounted: true // Better open performance on mobile.
              }}
            >
              {drawer}
            </Drawer>
          </Hidden>
          <Hidden xsDown implementation="css">
            <Drawer
              classes={{
                paper: classes.drawerPaper
              }}
              variant="permanent"
              open
            >
              {drawer}
            </Drawer>
          </Hidden>
        </nav>

        <main className={classes.content}>
          <div className={classes.toolbar} />

          <Switch>
            <Route
              exact
              path="/"
              render={() => (
                <div>
                  <WelcomePage />
                </div>
              )}
            />
            <Route
              exact
              path="/WelcomePage"
              render={() => (
                <div>
                  <WelcomePage />
                </div>
              )}
            />
            <Route
              path="/ViewProducts"
              render={() => (
                <div>
                  <ViewProducts />
                </div>
              )}
            />
            <Route
              path="/AddProducts"
              render={() => (
                <div>
                  <AddProducts />
                </div>
              )}
            />
            <Route
              path="/SimpleTable"
              render={() => (
                <div>
                  <SimpleTable />
                </div>
              )}
            />
            <Route
              path="/SearchProduct"
              render={() => (
                <div>
                  <SearchProduct />
                </div>
              )}
            />
            <Route
              path="/DeleteProducts"
              render={() => (
                <div>
                  <DeleteProducts />
                </div>
              )}
            />
          </Switch>
        </main>
      </BrowserRouter>
    </div>
  );
}

MainLayout.propTypes = {
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  container: PropTypes.instanceOf(
    typeof Element === "undefined" ? Object : Element
  )
};

export default MainLayout;
