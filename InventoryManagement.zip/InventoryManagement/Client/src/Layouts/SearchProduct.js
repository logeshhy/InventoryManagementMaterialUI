import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import SearchForm from "../Components/SearchForm";
import { Typography, Grid } from "@material-ui/core";
import { green, pink } from "@material-ui/core/colors";
import Avatar from "@material-ui/core/Avatar";
import FolderIcon from "@material-ui/icons/Folder";
import PageviewIcon from "@material-ui/icons/Pageview";
import AssignmentIcon from "@material-ui/icons/Assignment";
import Divider from "@material-ui/core/Divider";

const useStyles = makeStyles(theme => ({
  paperstyle: {
    display: "flex",
    "& > *": {
      margin: "auto",
      marginTop: theme.spacing(4)
      // paddingRight:theme.spacing(4),
      // width: theme.spacing(75),
      // height: theme.spacing(16),
    }
  },
  paperHeading: {
    marginLeft: "10px",
    marginTop: "25px",
    marginRight: "50px"
  },
  green: {
    color: "#fff",
    backgroundColor: green[500],
    marginTop: "20px",
    marginLeft: "50px",
    height: "30px",
    width: "30px"

    // fontSize:"100px",
    // height: "50px",
    // width: "50px"
  }

  // AddProductsBg: {
  //   backgroundImage: `url(${bg})`,
  //   height: "100vh"
  // }
}));

export default function SearchProduct() {
  const classes = useStyles();

  return (
    <div className={classes.paperstyle}>
      <div>
        <Paper elevation={15} rounded>
          <Grid container direction="row" alignItems="center">
            <Grid item>
              <Avatar className={classes.green}>
                <AssignmentIcon fontSize="medium" />
              </Avatar>
            </Grid>
            <Grid item>
              <Typography
                className={classes.paperHeading}
                variant="h5"
                color="Primary"
              >
                SEARCH PRODUCTS
              </Typography>
            </Grid>
          </Grid>
          <Divider variant="middle" style={{ marginTop: "5px" }} />
          <SearchForm />
        </Paper>
      </div>
    </div>
  );
}
