const express = require("express");
const mysql = require("mysql");
const bodyParser = require("body-parser");
const cors = require("cors");
let app = express();
// app.use(express())
app.use(bodyParser.json());
app.use(cors());

var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "inventorymanagement"
});

connection.connect(err => {
  if (!err) console.log("conn");
  else console.log(err);
});

app.get("/productslist", (req, res) => {
  connection.query("select * from addproducts", (err, rows) => {
    if (!err) console.log(rows), res.json({ data: rows });
    //data variable is not mandatory but inorder to pass the result we need it
    else console.log(err);
    // connection.end()
  });
});

app.get("/productslist/:idaddproducts", (req, res) => {
  const id = req.params.idaddproducts;
  console.log(id);
  connection.query(
    "SELECT * FROM `addproducts` where idaddproducts = ? ",
    id,
    (err, rows) => {
      if (!err) console.log(rows), res.json({ data: rows });
      //data variable is not mandatory but inorder to pass the result we need it
      else console.log(err);
      // connection.end()
    }
  );
});

app.get("/productslist/delete/:idaddproducts", (req, res) => {
  const id = req.params.idaddproducts;
  console.log(id);
  connection.query(
    "DELETE FROM `addproducts` where idaddproducts = ? ",
    id,
    (err, rows) => {
      if (!err) console.log(rows), res.json({ data: rows });
      //data variable is not mandatory but inorder to pass the result we need it
      else console.log(err);
      // connection.end()
    }
  );
});

app.post("/add", (req, res) => {
  console.log(req.query);

  const {
    productName,
    productId,
    productBrand,
    productQuantity,
    productPrice,
    productType
  } = req.query;

  const Name = req.body.productName;
  const Id = req.body.productId;
  const Brand = req.body.productBrand;
  const Quantity = req.body.productQuantity;
  const Price = req.body.productPrice;
  const Type = req.body.productType;
  // const {Name, Age} = req.query
  // const name = req.body.Name
  // const age = req.body.Age
  //   console.log(Name,Id)
  //   res.send('added')
  const INSERT_USER_QUERY = `INSERT INTO addproducts (productName, productId, productBrand, productQuantity, productPrice, productType)
 values ('${Name}', '${Id}', '${Brand}', '${Quantity}', '${Price}', '${Type}')`;
  console.log(INSERT_USER_QUERY);
  connection.query(INSERT_USER_QUERY, (err, rows) => {
    if (err) return console.log(err);
    // return res.json("added")
    else return console.log(rows);
  });
  //   connection.end();
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log("Server Listening on Port : ", PORT);
});
